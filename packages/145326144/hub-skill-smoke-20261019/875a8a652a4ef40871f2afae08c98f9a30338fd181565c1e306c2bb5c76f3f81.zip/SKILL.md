---
name: hub-skill-smoke-20261019
description: 仅用于验证 MyCrew Skill Hub 投稿、展示和下载链路。
version: 0.0.1
---

# Skill Hub 链路测试

这是无外部调用、无文件修改的测试 Skill。仅用于验证目录展示、详情读取和安装流程。
